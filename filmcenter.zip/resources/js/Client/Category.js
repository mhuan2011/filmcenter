import { Card, Col, Row, Spin } from 'antd'
import React, { useContext, useEffect, useState } from 'react'
import { AppContext } from '../Context';

const Category = () => {
  
  return (
    <Row>
      Category Page
    </Row>
  )
}

export default Category