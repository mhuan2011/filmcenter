<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS32znjTSHsQytNaSnCjX9lDEsenFOvH5PSrGGEBQGmLkEvl2Rhsis4rW4tC6_-9xpzJWg&usqp=CAU" />
    <title>Film Center</title>
</head>

<body>

</body>

</html><?php /**PATH C:\xampp\htdocs\thuctap\filmcenter\resources\views/welcome.blade.php ENDPATH**/ ?>