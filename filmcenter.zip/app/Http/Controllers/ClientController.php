<?php

namespace App\Http\Controllers;

use App\Models\CinemaHall;
use App\Models\Movies;
use App\Models\Show;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Date;

class ClientController extends Controller
{
    public function getMovieShow()
    {
        $date = Carbon::now('Asia/Ho_Chi_Minh')->format('Y-m-d');
        $time = Carbon::now('Asia/Ho_Chi_Minh')->format('H:i:s');

        $item = Show::where([['start_time', '>', $time], ['date', '=', $date]])->orWhere('date', '>', $date)->get();
        $movie_id = [];
        foreach ($item as $show) {
            array_push($movie_id, $show->movie_id);
        }

        $movies = Movies::whereIn('id', $movie_id)->get();
        if (is_null($item)) {
            return response()->json([
                'status' => false,
                'message' => 'Not found',
            ]);
        }
        return response()->json([
            'status' => true,
            'data' => $movies,
        ]);
    }


    public function getShowWithMovieCinema(Request $request)
    {
        $date = Carbon::now('Asia/Ho_Chi_Minh')->format('Y-m-d');
        $time = Carbon::now('Asia/Ho_Chi_Minh')->format('H:i:s');

        $cinema_id = $request->cinema_id;
        $movie_id = $request->movie_id;
        $data = [];
        $cinema_hall = CinemaHall::selectRaw('cinema_hall.id')
            ->join('cinema', 'cinema.id', '=', 'cinema_hall.cinema_id')->where('cinema.id', $cinema_id)->get();

        $cinema_hall_id_list = [];
        foreach ($cinema_hall as $item) {
            array_push($cinema_hall_id_list, $item->id);
        };

        $date_show = Show::where('movie_id', $movie_id)->where([['start_time', '>', $time], ['date', '=', $date]])->orWhere('date', '>', $date)->whereIn('cinema_hall_id', $cinema_hall_id_list)->groupBy('date')->get('date');



        foreach ($date_show as $d) {
            $temp = Show::selectRaw('id, cinema_hall_id, start_time')->where([['start_time', '>', $time], ['date', '=', $date]])->orWhere('date', '>', $date)->where('movie_id', $movie_id)->where('date', $d->date)->whereIn('cinema_hall_id', $cinema_hall_id_list)->orderBy('start_time', 'asc')->get();

            array_push($data, [
                'date' => $d->date,
                'show' => $temp
            ]);
        };


        return response()->json([
            'status' => true,
            'data' => $data,
        ]);
    }

    public function getInforShow($id)
    {
        $item = Show::where('id', $id)->with('cinema_hall')->first();
        if (is_null($item)) {
            return response()->json([
                'status' => false,
                'message' => 'Not found',
            ]);
        }
        return response()->json([
            'status' => true,
            'data' => $item,
        ]);
    }
}
